#!/bin/bash
cd /opt/mikrotik-panel

# Автоматическая установка зависимостей
apt update
apt install -y python3 python3-venv python3-pip curl unzip

# Создание окружения, если не существует
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi

source venv/bin/activate
pip install --upgrade pip
pip install flask flask-socketio paramiko requests

# Запуск панели
python3 app/main.py
