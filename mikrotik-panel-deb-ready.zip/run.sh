#!/bin/bash
cd /opt/mikrotik-ssh-panel
source venv/bin/activate
python3 app/main.py
